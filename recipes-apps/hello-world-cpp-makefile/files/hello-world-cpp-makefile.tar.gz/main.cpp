#include <iostream>

int main(int argc, char *argv[]) {
    std::cout << "Hello Yocto!! Makefile" << std::endl;
    return EXIT_SUCCESS;
}