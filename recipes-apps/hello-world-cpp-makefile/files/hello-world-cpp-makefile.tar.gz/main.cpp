#include <iostream>

int main(int argc, char *argv[]) {
    std::cout << "Hello Yocto!!" << std::endl;
    return EXIT_SUCCESS;
}